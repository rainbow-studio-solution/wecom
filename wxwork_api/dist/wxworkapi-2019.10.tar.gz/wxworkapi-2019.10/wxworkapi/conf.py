#!/usr/bin/python
# -*- coding:utf-8 -*-

## 设置为true会打印一些调试信息
DEBUG = True 

